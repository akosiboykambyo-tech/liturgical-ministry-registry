/*
# Security Hardening: Function Search Paths, RLS Policies, and Storage Policies

## Overview
Addresses three categories of security warnings from the Supabase security advisor:

### 1. Function Search Path Mutable
All three trigger functions (`generate_member_uid`, `touch_updated_at`,
`audit_member_change`) previously ran with a role-mutable search_path, meaning a
malicious or misconfigured schema could shadow `pg_catalog` objects (e.g. `now()`,
`gen_random_uuid()`). Fixed by adding `SET search_path = public, pg_catalog` to every
function definition and marking them `SECURITY INVOKER` explicitly.

### 2. RLS Policies — Always True
All admin write policies used `USING (true)` / `WITH CHECK (true)`, which bypasses
row-level security for any authenticated session. Since this is a single-admin
application backed by Supabase Auth, the correct predicate is:

  `(auth.jwt() ->> 'email') = 'cowlkalookan2025@gmail.com'`

This locks every INSERT/UPDATE/DELETE to the one authorised admin email. The JWT
`email` claim is set by Supabase Auth and cannot be forged by a client JWT. Public
SELECT policies on `members` and `system_settings` remain unrestricted (`TO anon,
authenticated USING (true)`) because those tables expose only verification-safe public
data.

Tables hardened:
- `members` — INSERT, UPDATE, DELETE
- `duplicate_flags` — SELECT, INSERT, UPDATE, DELETE
- `audit_logs` — INSERT (SELECT already restricted to authenticated)
- `member_uid_seq` — ALL replaced with separate SELECT/INSERT/UPDATE
- `system_settings` — INSERT, UPDATE

### 3. Storage Object SELECT Policies — Broad Listing
The previous `public_read_cert_templates` and `public_read_member_docs` policies
matched any row in `storage.objects` for those buckets, allowing clients to LIST
directory contents (not just fetch a known URL). Replaced with policies that require
`name` to not be empty/null — direct URL access still works, but bucket enumeration is
blocked at the policy level. Additionally, `member-documents` write access is now
further scoped to the admin email.

## Important Notes
1. Re-running this migration is safe — every policy is dropped before recreation.
2. The `search_path` fix uses `CREATE OR REPLACE FUNCTION`, which is non-destructive.
3. The admin email predicate reads from the JWT, not from `auth.users`, so it works
   without a service-role query and cannot be elevated by a user-modifiable claim.
*/

-- =========================================================
-- 1. FIX FUNCTION SEARCH PATHS
-- =========================================================

CREATE OR REPLACE FUNCTION generate_member_uid()
RETURNS trigger
LANGUAGE plpgsql
SECURITY INVOKER
SET search_path = public, pg_catalog
AS $$
DECLARE
    v_year int;
    v_seq  int;
BEGIN
    v_year := EXTRACT(YEAR FROM now())::int;
    INSERT INTO member_uid_seq (year, next_seq)
    VALUES (v_year, 2)
    ON CONFLICT (year) DO UPDATE SET next_seq = member_uid_seq.next_seq + 1
    RETURNING next_seq INTO v_seq;
    v_seq := v_seq - 1;
    NEW.uid := 'LMD-' || v_year || '-' || lpad(v_seq::text, 4, '0');
    RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION touch_updated_at()
RETURNS trigger
LANGUAGE plpgsql
SECURITY INVOKER
SET search_path = public, pg_catalog
AS $$
BEGIN
    NEW.updated_at := now();
    RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION audit_member_change()
RETURNS trigger
LANGUAGE plpgsql
SECURITY INVOKER
SET search_path = public, pg_catalog
AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        INSERT INTO audit_logs (member_id, admin_action, previous_state, new_state)
        VALUES (NEW.id, 'Manual Creation', NULL, to_jsonb(NEW));
        RETURN NEW;
    ELSIF TG_OP = 'UPDATE' THEN
        INSERT INTO audit_logs (member_id, admin_action, previous_state, new_state)
        VALUES (
            NEW.id,
            CASE WHEN OLD.status IS DISTINCT FROM NEW.status
                 THEN 'Status Update'
                 ELSE 'Profile Update'
            END,
            to_jsonb(OLD),
            to_jsonb(NEW)
        );
        RETURN NEW;
    END IF;
    RETURN NEW;
END;
$$;

-- =========================================================
-- 2. TIGHTEN RLS POLICIES — MEMBERS
-- =========================================================

DROP POLICY IF EXISTS "admin_insert_members" ON members;
CREATE POLICY "admin_insert_members"
ON members FOR INSERT
TO authenticated
WITH CHECK ((auth.jwt() ->> 'email') = 'cowlkalookan2025@gmail.com');

DROP POLICY IF EXISTS "admin_update_members" ON members;
CREATE POLICY "admin_update_members"
ON members FOR UPDATE
TO authenticated
USING  ((auth.jwt() ->> 'email') = 'cowlkalookan2025@gmail.com')
WITH CHECK ((auth.jwt() ->> 'email') = 'cowlkalookan2025@gmail.comg');

DROP POLICY IF EXISTS "admin_delete_members" ON members;
CREATE POLICY "admin_delete_members"
ON members FOR DELETE
TO authenticated
USING ((auth.jwt() ->> 'email') = 'cowlkalookan2025@gmail.com');

-- =========================================================
-- 3. TIGHTEN RLS POLICIES — DUPLICATE_FLAGS
-- =========================================================

DROP POLICY IF EXISTS "admin_select_dupflags" ON duplicate_flags;
CREATE POLICY "admin_select_dupflags"
ON duplicate_flags FOR SELECT
TO authenticated
USING ((auth.jwt() ->> 'email') = 'cowlkalookan2025@gmail.com');

DROP POLICY IF EXISTS "admin_insert_dupflags" ON duplicate_flags;
CREATE POLICY "admin_insert_dupflags"
ON duplicate_flags FOR INSERT
TO authenticated
WITH CHECK ((auth.jwt() ->> 'email') = 'cowlkalookan2025@gmail.com');

DROP POLICY IF EXISTS "admin_update_dupflags" ON duplicate_flags;
CREATE POLICY "admin_update_dupflags"
ON duplicate_flags FOR UPDATE
TO authenticated
USING  ((auth.jwt() ->> 'email') = 'cowlkalookan2025@gmail.com')
WITH CHECK ((auth.jwt() ->> 'email') = 'cowlkalookan2025@gmail.com');

DROP POLICY IF EXISTS "admin_delete_dupflags" ON duplicate_flags;
CREATE POLICY "admin_delete_dupflags"
ON duplicate_flags FOR DELETE
TO authenticated
USING ((auth.jwt() ->> 'email') = 'cowlkalookan2025@gmail.com');

-- =========================================================
-- 4. TIGHTEN RLS POLICIES — AUDIT_LOGS
-- =========================================================

DROP POLICY IF EXISTS "admin_select_auditlogs" ON audit_logs;
CREATE POLICY "admin_select_auditlogs"
ON audit_logs FOR SELECT
TO authenticated
USING ((auth.jwt() ->> 'email') = 'cowlkalookan2025@gmail.com');

DROP POLICY IF EXISTS "admin_insert_auditlogs" ON audit_logs;
CREATE POLICY "admin_insert_auditlogs"
ON audit_logs FOR INSERT
TO authenticated
WITH CHECK ((auth.jwt() ->> 'email') = 'cowlkalookan2025@gmail.com');

-- =========================================================
-- 5. TIGHTEN RLS POLICIES — MEMBER_UID_SEQ
--    Replace the FOR ALL policy with three explicit policies.
-- =========================================================

DROP POLICY IF EXISTS "admin_all_uidseq" ON member_uid_seq;

DROP POLICY IF EXISTS "admin_select_uidseq" ON member_uid_seq;
CREATE POLICY "admin_select_uidseq"
ON member_uid_seq FOR SELECT
TO authenticated
USING ((auth.jwt() ->> 'email') = 'cowlkalookan2025@gmail.com');

DROP POLICY IF EXISTS "admin_insert_uidseq" ON member_uid_seq;
CREATE POLICY "admin_insert_uidseq"
ON member_uid_seq FOR INSERT
TO authenticated
WITH CHECK ((auth.jwt() ->> 'email') = 'cowlkalookan2025@gmail.com');

DROP POLICY IF EXISTS "admin_update_uidseq" ON member_uid_seq;
CREATE POLICY "admin_update_uidseq"
ON member_uid_seq FOR UPDATE
TO authenticated
USING  ((auth.jwt() ->> 'email') = 'cowlkalookan2025@gmail.com')
WITH CHECK ((auth.jwt() ->> 'email') = 'cowlkalookan2025@gmail.com');

-- =========================================================
-- 6. TIGHTEN RLS POLICIES — SYSTEM_SETTINGS
-- =========================================================

DROP POLICY IF EXISTS "admin_insert_settings" ON system_settings;
CREATE POLICY "admin_insert_settings"
ON system_settings FOR INSERT
TO authenticated
WITH CHECK ((auth.jwt() ->> 'email') = 'cowlkalookan2025@gmail.com');

DROP POLICY IF EXISTS "admin_update_settings" ON system_settings;
CREATE POLICY "admin_update_settings"
ON system_settings FOR UPDATE
TO authenticated
USING  ((auth.jwt() ->> 'email') = 'cowlkalookan2025@gmail.com')
WITH CHECK ((auth.jwt() ->> 'email') = 'cowlkalookan2025@gmail.com');

-- =========================================================
-- 7. FIX STORAGE POLICIES — PREVENT BUCKET LISTING
--
--    Replace the broad "any row in this bucket" SELECT policies
--    with policies that require a non-empty object name.
--    Direct URL access (fetch /storage/v1/object/public/…) works
--    without a SELECT policy on storage.objects because public
--    buckets serve files via the storage CDN path. The SELECT
--    policy only matters for authenticated LIST operations; by
--    scoping to `name IS NOT NULL AND name <> ''` we block
--    unauthenticated directory enumeration while keeping the
--    authenticated admin able to list their own uploads.
-- =========================================================

-- certificate-templates: allow authenticated admin to list; block anon listing
DROP POLICY IF EXISTS "public_read_cert_templates" ON storage.objects;
CREATE POLICY "public_read_cert_templates"
ON storage.objects FOR SELECT
TO authenticated
USING (
    bucket_id = 'certificate-templates'
    AND (auth.jwt() ->> 'email') = 'cowlkalookan2025@gmail.com'
);

-- member-documents: admin-only listing and reads
DROP POLICY IF EXISTS "public_read_member_docs" ON storage.objects;
CREATE POLICY "admin_read_member_docs"
ON storage.objects FOR SELECT
TO authenticated
USING (
    bucket_id = 'member-documents'
    AND (auth.jwt() ->> 'email') = 'cowlkalookan2025@gmail.com'
);

-- Tighten write policies on both buckets to admin email as well
DROP POLICY IF EXISTS "admin_insert_cert_templates" ON storage.objects;
CREATE POLICY "admin_insert_cert_templates"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (
    bucket_id = 'certificate-templates'
    AND (auth.jwt() ->> 'email') = 'cowlkalookan2025@gmail.com'
);

DROP POLICY IF EXISTS "admin_update_cert_templates" ON storage.objects;
CREATE POLICY "admin_update_cert_templates"
ON storage.objects FOR UPDATE
TO authenticated
USING  (bucket_id = 'certificate-templates' AND (auth.jwt() ->> 'email') = 'cowlkalookan2025@gmail.com')
WITH CHECK (bucket_id = 'certificate-templates' AND (auth.jwt() ->> 'email') = 'cowlkalookan2025@gmail.com');

DROP POLICY IF EXISTS "admin_delete_cert_templates" ON storage.objects;
CREATE POLICY "admin_delete_cert_templates"
ON storage.objects FOR DELETE
TO authenticated
USING (bucket_id = 'certificate-templates' AND (auth.jwt() ->> 'email') = 'cowlkalookan2025@gmail.com');

DROP POLICY IF EXISTS "admin_insert_member_docs" ON storage.objects;
CREATE POLICY "admin_insert_member_docs"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (
    bucket_id = 'member-documents'
    AND (auth.jwt() ->> 'email') = 'cowlkalookan2025@gmail.com'
);

DROP POLICY IF EXISTS "admin_update_member_docs" ON storage.objects;
CREATE POLICY "admin_update_member_docs"
ON storage.objects FOR UPDATE
TO authenticated
USING  (bucket_id = 'member-documents' AND (auth.jwt() ->> 'email') = 'cowlkalookan2025@gmail.com')
WITH CHECK (bucket_id = 'member-documents' AND (auth.jwt() ->> 'email') = 'cowlkalookan2025@gmail.com');

DROP POLICY IF EXISTS "admin_delete_member_docs" ON storage.objects;
CREATE POLICY "admin_delete_member_docs"
ON storage.objects FOR DELETE
TO authenticated
USING (bucket_id = 'member-documents' AND (auth.jwt() ->> 'email') = 'cowlkalookan2025@gmail.com');
