/*
# Add text alignment to signatories

## Purpose
Adds an `alignment` column to the `signatories` table so each signatory's
name/title text block can be left-aligned, centered, or right-aligned on the
certificate. This supports the new alignment toggle in the Signatories manager.

## Changes
1. New column on `signatories`:
   - `alignment` (text, NOT NULL, DEFAULT 'left', CHECK in 'left','center','right')
   - Controls CSS text-align / canvas textAlign for the signatory text block.

## Security
- No RLS policy changes. Existing policies remain in effect.
*/

DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'signatories' AND column_name = 'alignment'
  ) THEN
    ALTER TABLE signatories
      ADD COLUMN alignment text NOT NULL DEFAULT 'left'
        CHECK (alignment IN ('left', 'center', 'right'));
  END IF;
END $$;