-- Atomic "set default" for certificate templates.
-- Toggles a single row's is_default to true and all other certificate_template
-- rows to false in one statement, so RLS can't leave two defaults in place
-- across a two-step client update.
CREATE OR REPLACE FUNCTION public.set_default_certificate_template(p_key text)
RETURNS void
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  UPDATE system_settings
  SET is_default = (key = p_key)
  WHERE key LIKE 'certificate_template%';
$$;

-- SECURITY DEFINER runs as the table owner, bypassing RLS. Restrict execution
-- to the admin email so only the Console can flip the default. The RLS
-- policies on system_settings already gate INSERT/UPDATE to that same email,
-- so exposing this RPC to authenticated keeps the contract identical.
REVOKE ALL ON FUNCTION public.set_default_certificate_template(text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.set_default_certificate_template(text) TO authenticated;
