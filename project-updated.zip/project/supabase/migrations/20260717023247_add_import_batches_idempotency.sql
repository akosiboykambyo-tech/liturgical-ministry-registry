/*
# Add import_batches table for idempotency tracking

## Purpose
When an admin uploads a CSV, we compute a content hash of the file and store it
in `import_batches`. Before processing a new upload, we check whether a batch
with the same hash has already been fully processed. If so, we warn the admin
that this exact file was already imported, preventing accidental double-imports
of the same CSV.

## New Tables
- `import_batches`
  - `id` (uuid, PK) — unique batch identifier
  - `file_hash` (text, NOT NULL, UNIQUE) — SHA-256 hash of the raw CSV content
  - `file_name` (text) — original uploaded filename
  - `row_count` (int) — number of valid rows in the batch
  - `unique_inserted` (int) — how many rows were inserted as new members
  - `duplicates_routed` (int) — how many rows were routed to pending merges
  - `status` (text) — 'processing' | 'completed' | 'partial'
  - `created_at` (timestamptz) — when the batch was first uploaded
  - `completed_at` (timestamptz) — when processing finished

## Security
- RLS enabled with full CRUD for authenticated users (admin-only app).
- No anon access — this is an admin audit table.

## Notes
1. The unique constraint on `file_hash` is the idempotency key: re-uploading
   the same CSV produces the same hash, so we can detect and warn.
2. `status='processing'` is set on upload; updated to 'completed' or 'partial'
   when the import finishes.
3. This table is write-once per unique file — a re-upload attempt will find
   the existing record and the frontend can warn the user before proceeding.
*/

CREATE TABLE IF NOT EXISTS import_batches (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  file_hash text NOT NULL UNIQUE,
  file_name text,
  row_count int NOT NULL DEFAULT 0,
  unique_inserted int NOT NULL DEFAULT 0,
  duplicates_routed int NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'processing',
  created_at timestamptz NOT NULL DEFAULT now(),
  completed_at timestamptz
);

ALTER TABLE import_batches ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_import_batches" ON import_batches;
CREATE POLICY "select_import_batches" ON import_batches FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "insert_import_batches" ON import_batches;
CREATE POLICY "insert_import_batches" ON import_batches FOR INSERT
  TO authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "update_import_batches" ON import_batches;
CREATE POLICY "update_import_batches" ON import_batches FOR UPDATE
  TO authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "delete_import_batches" ON import_batches;
CREATE POLICY "delete_import_batches" ON import_batches FOR DELETE
  TO authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_import_batches_file_hash ON import_batches(file_hash);
CREATE INDEX IF NOT EXISTS idx_import_batches_status ON import_batches(status);
