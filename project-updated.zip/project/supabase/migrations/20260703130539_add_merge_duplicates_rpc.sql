-- RPC function to merge duplicate members with SECURITY DEFINER
-- This bypasses RLS policies since the function runs with the privileges
-- of the function owner (postgres), not the calling user.

CREATE OR REPLACE FUNCTION merge_duplicate_members(
  p_primary_id uuid,
  p_duplicate_ids uuid[],
  p_merged_ministries text[]
)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_primary_uid text;
  v_deleted_count int;
BEGIN
  -- Verify primary member exists
  SELECT uid INTO v_primary_uid FROM members WHERE id = p_primary_id;
  IF v_primary_uid IS NULL THEN
    RETURN json_build_object(
      'success', false,
      'error', 'Primary member not found'
    );
  END IF;

  -- Update the primary record with merged ministries
  UPDATE members
  SET 
    ministries = p_merged_ministries,
    updated_at = now()
  WHERE id = p_primary_id;

  -- Delete duplicate records
  DELETE FROM members
  WHERE id = ANY(p_duplicate_ids);

  GET DIAGNOSTICS v_deleted_count = ROW_COUNT;

  -- Also clean up any duplicate_flags or scanned_duplicates referencing deleted members
  DELETE FROM duplicate_flags
  WHERE existing_member_id = ANY(p_duplicate_ids);

  RETURN json_build_object(
    'success', true,
    'primary_id', p_primary_id,
    'deleted_count', v_deleted_count
  );
END;
$$;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION merge_duplicate_members(uuid, uuid[], text[]) TO authenticated;

-- RPC function to resolve a scanned duplicate group
CREATE OR REPLACE FUNCTION resolve_scanned_duplicate_merge(
  p_scanned_id uuid
)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_member_ids uuid[];
  v_primary_id uuid;
  v_sorted_ids uuid[];
  v_ministries text[];
  v_merged_ministries text[];
  v_rec record;
BEGIN
  -- Get the scanned duplicate group
  SELECT member_ids INTO v_member_ids
  FROM scanned_duplicates
  WHERE id = p_scanned_id AND resolved = false;

  IF v_member_ids IS NULL OR array_length(v_member_ids, 1) IS NULL THEN
    RETURN json_build_object(
      'success', false,
      'error', 'Scanned duplicate group not found or already resolved'
    );
  END IF;

  -- Find the oldest member (primary) by created_at
  SELECT id INTO v_primary_id
  FROM members
  WHERE id = ANY(v_member_ids)
  ORDER BY created_at ASC
  LIMIT 1;

  IF v_primary_id IS NULL THEN
    RETURN json_build_object(
      'success', false,
      'error', 'No members found for the scanned group'
    );
  END IF;

  -- Collect all unique ministries from all members
  SELECT array_agg(DISTINCT ministry) INTO v_merged_ministries
  FROM (
    SELECT unnest(ministries) AS ministry
    FROM members
    WHERE id = ANY(v_member_ids)
  ) AS m;

  -- Get IDs to delete (all except primary)
  SELECT array_agg(id) INTO v_sorted_ids
  FROM members
  WHERE id = ANY(v_member_ids) AND id != v_primary_id;

  -- Call the merge function
  PERFORM merge_duplicate_members(v_primary_id, v_sorted_ids, v_merged_ministries);

  -- Mark the scanned duplicate as resolved
  UPDATE scanned_duplicates
  SET 
    resolved = true,
    resolution = 'merged',
    resolved_at = now()
  WHERE id = p_scanned_id;

  -- Also mark any other scanned_duplicate groups that involved the deleted members
  -- as resolved since those members no longer exist
  UPDATE scanned_duplicates
  SET 
    resolved = true,
    resolution = 'members_deleted',
    resolved_at = now()
  WHERE resolved = false
    AND id != p_scanned_id
    AND member_ids && v_sorted_ids;

  RETURN json_build_object(
    'success', true,
    'primary_id', v_primary_id,
    'deleted_ids', v_sorted_ids,
    'merged_ministries', v_merged_ministries
  );
END;
$$;

GRANT EXECUTE ON FUNCTION resolve_scanned_duplicate_merge(uuid) TO authenticated;

-- RPC function to mark scanned duplicate as separate (not duplicates)
CREATE OR REPLACE FUNCTION resolve_scanned_duplicate_separate(
  p_scanned_id uuid
)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  UPDATE scanned_duplicates
  SET 
    resolved = true,
    resolution = 'separate',
    resolved_at = now()
  WHERE id = p_scanned_id AND resolved = false;

  IF NOT FOUND THEN
    RETURN json_build_object(
      'success', false,
      'error', 'Scanned duplicate group not found or already resolved'
    );
  END IF;

  RETURN json_build_object('success', true);
END;
$$;

GRANT EXECUTE ON FUNCTION resolve_scanned_duplicate_separate(uuid) TO authenticated;