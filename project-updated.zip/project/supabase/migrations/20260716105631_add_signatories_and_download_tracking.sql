/*
# Add Signatories and Certificate Download Tracking

## Purpose
This migration introduces two new tables to support dynamic signatories on certificates
and reprint tracking for downloaded certificates.

## 1. New Tables

### `signatories`
Stores signature images, names, titles, and display rules for certificate rendering.
- `id` (uuid, PK)
- `name` (text) — signatory's full name (e.g. "Rev. Fr. Juan Dela Cruz")
- `title` (text) — role/title (e.g. "Parish Priest", "Diocesan Coordinator")
- `signature_url` (text, nullable) — URL to uploaded signature image in storage
- `display_type` (text) — 'static' (appears on ALL certificates) or 'dynamic' (appears only when certificate ministry matches)
- `ministry` (text, nullable) — for dynamic signatories: the ministry that triggers display
- `position_x` (int) — X coordinate on the certificate canvas (default 60)
- `position_y` (int) — Y coordinate on the certificate canvas (default 720)
- `width` (int) — signature image width in px (default 150)
- `is_active` (boolean, default true) — soft-delete / toggle visibility
- `sort_order` (int, default 0) — controls stacking order when multiple signatories render
- `created_at` (timestamptz)
- `updated_at` (timestamptz)

### `certificate_downloads`
Tracks every certificate download for reprint suffix calculation.
- `id` (uuid, PK)
- `member_id` (uuid, FK to members.id ON DELETE CASCADE)
- `ministry` (text, nullable) — which ministry certificate was downloaded (for multi-ministry members)
- `download_count` (int, default 1) — incrementing counter per member+ministry
- `created_at` (timestamptz)
- `updated_at` (timestamptz)

## 2. Security (RLS)

Both tables follow the existing project pattern:
- Admin (authenticated via specific email) has full CRUD access.
- Public (anon) can read signatories (needed for certificate rendering on /verify).
- Public (anon) can INSERT into certificate_downloads (to record downloads from the public verify page).
- Public (anon) can read certificate_downloads (to check current count before incrementing).

## 3. Indexes
- `certificate_downloads` has a unique index on (member_id, ministry) to ensure one counter row per member+ministry combination.
- `signatories` has an index on `is_active` for efficient filtering.

## Notes
- The `members` table already has a `ministries` text[] column — no schema change needed for multi-ministry support.
- Certificate template settings (fonts, header/body/footer text) are stored as JSONB in `system_settings`, so no new columns are needed there either.
*/

-- ============================================================
-- SIGNATORIES TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS signatories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  title text NOT NULL DEFAULT '',
  signature_url text,
  display_type text NOT NULL DEFAULT 'static' CHECK (display_type IN ('static', 'dynamic')),
  ministry text,
  position_x integer NOT NULL DEFAULT 60,
  position_y integer NOT NULL DEFAULT 720,
  width integer NOT NULL DEFAULT 150,
  is_active boolean NOT NULL DEFAULT true,
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE signatories ENABLE ROW LEVEL SECURITY;

-- Admin full access
DROP POLICY IF EXISTS "admin_full_access_signatories" ON signatories;
CREATE POLICY "admin_full_access_signatories" ON signatories
  FOR ALL TO authenticated
  USING ((auth.jwt() ->> 'email') = 'cowlkalookan2025@gmail.com')
  WITH CHECK ((auth.jwt() ->> 'email') = 'cowlkalookan2025@gmail.com');

-- Public can read active signatories (for certificate rendering)
DROP POLICY IF EXISTS "public_read_signatories" ON signatories;
CREATE POLICY "public_read_signatories" ON signatories
  FOR SELECT TO anon, authenticated
  USING (true);

CREATE INDEX IF NOT EXISTS idx_signatories_active ON signatories (is_active);

-- ============================================================
-- CERTIFICATE_DOWNLOADS TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS certificate_downloads (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  member_id uuid NOT NULL REFERENCES members(id) ON DELETE CASCADE,
  ministry text,
  download_count integer NOT NULL DEFAULT 1,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE certificate_downloads ENABLE ROW LEVEL SECURITY;

-- Admin full access
DROP POLICY IF EXISTS "admin_full_access_downloads" ON certificate_downloads;
CREATE POLICY "admin_full_access_downloads" ON certificate_downloads
  FOR ALL TO authenticated
  USING ((auth.jwt() ->> 'email') = 'cowlkalookan2025@gmail.com')
  WITH CHECK ((auth.jwt() ->> 'email') = 'cowlkalookan2025@gmail.com');

-- Public can read download counts (to determine reprint suffix)
DROP POLICY IF EXISTS "public_read_downloads" ON certificate_downloads;
CREATE POLICY "public_read_downloads" ON certificate_downloads
  FOR SELECT TO anon, authenticated
  USING (true);

-- Public can insert new download records (first download)
DROP POLICY IF EXISTS "public_insert_downloads" ON certificate_downloads;
CREATE POLICY "public_insert_downloads" ON certificate_downloads
  FOR INSERT TO anon, authenticated
  WITH CHECK (true);

-- Public can update download count (increment on reprint)
DROP POLICY IF EXISTS "public_update_downloads" ON certificate_downloads;
CREATE POLICY "public_update_downloads" ON certificate_downloads
  FOR UPDATE TO anon, authenticated
  USING (true) WITH CHECK (true);

-- Unique index: one counter row per member + ministry combination
CREATE UNIQUE INDEX IF NOT EXISTS idx_cert_downloads_member_ministry
  ON certificate_downloads (member_id, COALESCE(ministry, ''));
