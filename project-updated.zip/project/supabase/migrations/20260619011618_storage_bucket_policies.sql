/*
# Storage bucket policies for certificate templates and member documents

## Changes
1. `certificate-templates` bucket (public read) — holds the admin-uploaded certificate
   background image. Public read is required so the public /verify page can fetch the
   template to render a downloadable certificate client-side.
2. `member-documents` bucket — holds scanned recommendation letters. Public read is
   enabled so the admin (and only the admin via the gated UI) can view uploaded scans
   directly from the bucket URL. Writes are restricted to authenticated admin.

## Security
- certificate-templates: public SELECT, authenticated INSERT/UPDATE/DELETE.
- member-documents: public SELECT (so the image renders in the admin detail view),
  authenticated INSERT/UPDATE/DELETE.
*/

-- certificate-templates: public read, admin write
DROP POLICY IF EXISTS "public_read_cert_templates" ON storage.objects;
CREATE POLICY "public_read_cert_templates"
ON storage.objects FOR SELECT
TO anon, authenticated
USING (bucket_id = 'certificate-templates');

DROP POLICY IF EXISTS "admin_insert_cert_templates" ON storage.objects;
CREATE POLICY "admin_insert_cert_templates"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (bucket_id = 'certificate-templates');

DROP POLICY IF EXISTS "admin_update_cert_templates" ON storage.objects;
CREATE POLICY "admin_update_cert_templates"
ON storage.objects FOR UPDATE
TO authenticated
USING (bucket_id = 'certificate-templates') WITH CHECK (bucket_id = 'certificate-templates');

DROP POLICY IF EXISTS "admin_delete_cert_templates" ON storage.objects;
CREATE POLICY "admin_delete_cert_templates"
ON storage.objects FOR DELETE
TO authenticated
USING (bucket_id = 'certificate-templates');

-- member-documents: public read (renders in admin UI), admin write
DROP POLICY IF EXISTS "public_read_member_docs" ON storage.objects;
CREATE POLICY "public_read_member_docs"
ON storage.objects FOR SELECT
TO anon, authenticated
USING (bucket_id = 'member-documents');

DROP POLICY IF EXISTS "admin_insert_member_docs" ON storage.objects;
CREATE POLICY "admin_insert_member_docs"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (bucket_id = 'member-documents');

DROP POLICY IF EXISTS "admin_update_member_docs" ON storage.objects;
CREATE POLICY "admin_update_member_docs"
ON storage.objects FOR UPDATE
TO authenticated
USING (bucket_id = 'member-documents') WITH CHECK (bucket_id = 'member-documents');

DROP POLICY IF EXISTS "admin_delete_member_docs" ON storage.objects;
CREATE POLICY "admin_delete_member_docs"
ON storage.objects FOR DELETE
TO authenticated
USING (bucket_id = 'member-documents');
