/*
# Add expiration date and archived documents to members

## Purpose
Support document versioning and expiration tracking. Each member now has an
optional expiration date for their current recommendation letter. When a
member is renewed with a new letter, the previous letter's metadata is moved
into the `archived_documents` JSONB array before the new letter is linked.

## Modified Tables
- `members`
  - `expiration_date` (date, nullable) — expiration date of the current
    recommendation letter / membership period. Null means no expiration set.
  - `archived_documents` (jsonb, default '[]') — array of archived document
    metadata objects. Each object stores: { document_url, uploaded_at,
    archived_at, expiration_date }.

## Security
- No new tables. Existing RLS policies on `members` cover the new columns
  automatically (column-level privileges are not enabled, so existing
  row-level policies suffice).

## Notes
1. `archived_documents` is a JSONB array, not a separate table, to keep the
   document versioning co-located with the member record.
2. The frontend reads `expiration_date` to compute "Expired" and "Expiring Soon"
   derived statuses. These are NOT stored in the `status` column — the `status`
   column continues to hold the workflow status (Pending Verification, New,
   Renewed, Inactive). Expiration is a separate dimension computed at render
   time from `expiration_date` vs. the current date.
3. When a new recommendation letter is uploaded (renewal), the frontend:
   a. Reads the current `document_url` and `expiration_date`.
   b. Pushes { document_url, uploaded_at, archived_at: now, expiration_date }
      into `archived_documents`.
   c. Sets the new `document_url` and a new `expiration_date`.
*/

ALTER TABLE members
  ADD COLUMN IF NOT EXISTS expiration_date date;

ALTER TABLE members
  ADD COLUMN IF NOT EXISTS archived_documents jsonb NOT NULL DEFAULT '[]'::jsonb;

-- Index for quick lookup of expiring members
CREATE INDEX IF NOT EXISTS idx_members_expiration_date
  ON members (expiration_date)
  WHERE expiration_date IS NOT NULL;
