-- RPC function to merge an incoming duplicate into an existing member
-- Used when resolving duplicate_flags from CSV import interception
CREATE OR REPLACE FUNCTION merge_incoming_duplicate(
  p_flag_id uuid,
  p_existing_member_id uuid
)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_existing_ministries text[];
  v_incoming_ministries text[];
  v_merged_ministries text[];
  v_flag record;
BEGIN
  -- Get the duplicate flag
  SELECT * INTO v_flag
  FROM duplicate_flags
  WHERE id = p_flag_id AND resolved = false;

  IF v_flag.id IS NULL THEN
    RETURN json_build_object(
      'success', false,
      'error', 'Duplicate flag not found or already resolved'
    );
  END IF;

  -- Get existing member's ministries
  SELECT ministries INTO v_existing_ministries
  FROM members
  WHERE id = p_existing_member_id;

  IF v_existing_ministries IS NULL THEN
    RETURN json_build_object(
      'success', false,
      'error', 'Existing member not found'
    );
  END IF;

  -- Get incoming ministries from the flag
  v_incoming_ministries := v_flag.incoming_ministries;

  -- Merge ministries (combine arrays and dedupe)
  SELECT array_agg(DISTINCT ministry) INTO v_merged_ministries
  FROM (
    SELECT unnest(v_existing_ministries) AS ministry
    UNION
    SELECT unnest(v_incoming_ministries) AS ministry
  ) AS m;

  -- Update the existing member with merged ministries
  UPDATE members
  SET 
    ministries = v_merged_ministries,
    updated_at = now()
  WHERE id = p_existing_member_id;

  -- Mark the flag as resolved
  UPDATE duplicate_flags
  SET 
    resolved = true,
    resolution = 'merged',
    resolved_at = now()
  WHERE id = p_flag_id;

  RETURN json_build_object(
    'success', true,
    'member_id', p_existing_member_id,
    'merged_ministries', v_merged_ministries
  );
END;
$$;

GRANT EXECUTE ON FUNCTION merge_incoming_duplicate(uuid, uuid) TO authenticated;

-- RPC function to create a separate member from an incoming duplicate
-- Used when resolving duplicate_flags by keeping records separate
CREATE OR REPLACE FUNCTION create_separate_member_from_flag(
  p_flag_id uuid
)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_flag record;
  v_new_member_id uuid;
  v_new_uid text;
  v_uid_year int;
BEGIN
  -- Get the duplicate flag
  SELECT * INTO v_flag
  FROM duplicate_flags
  WHERE id = p_flag_id AND resolved = false;

  IF v_flag.id IS NULL THEN
    RETURN json_build_object(
      'success', false,
      'error', 'Duplicate flag not found or already resolved'
    );
  END IF;

  -- Generate a new UID (PENDING will be overwritten by trigger)
  -- Create the new member
  INSERT INTO members (
    first_name,
    last_name,
    parish,
    ministries,
    status,
    uid
  )
  VALUES (
    v_flag.incoming_first_name,
    v_flag.incoming_last_name,
    v_flag.incoming_parish,
    v_flag.incoming_ministries,
    'Pending Verification',
    'PENDING'
  )
  RETURNING id INTO v_new_member_id;

  -- Mark the flag as resolved
  UPDATE duplicate_flags
  SET 
    resolved = true,
    resolution = 'separate',
    resolved_at = now()
  WHERE id = p_flag_id;

  RETURN json_build_object(
    'success', true,
    'new_member_id', v_new_member_id
  );
END;
$$;

GRANT EXECUTE ON FUNCTION create_separate_member_from_flag(uuid) TO authenticated;