/*
# Liturgical Ministry Database - Core Schema

## Overview
Creates the relational model for a centralized Liturgical Ministry Database that tracks
members across 6 Standard Ministries, their verification lifecycle, audit trails,
duplicate-resolution queue, and system settings (certificate template config).

## New Tables
1. `members` — Core member records. Each member has a Unique Identifier (UID) of the
   form `LMD-<year>-####`, a four-state status lifecycle, ministries array, and an
   optional document_url linking to a scanned recommendation letter in Storage.
2. `duplicate_flags` — Pending-merge queue. When a CSV import or manual entry matches an
   existing member (same first_name, last_name, parish), the incoming row is parked here
   for the admin to review and resolve (merge vs. keep-separate).
3. `audit_logs` — Append-only digital paper trail. Records every data mutation
   (status update, manual creation, merge) with before/after JSONB snapshots.
4. `system_settings` — Key/value JSONB store for admin-configurable settings, primarily
   the certificate template metadata (storage path + overlay coordinates).

## Automation
- `generate_member_uid()` trigger function: on INSERT into members, auto-generates the
  human-readable `LMD-<year>-####` UID (zero-padded sequence within the year). The
  application inserts with a placeholder UID and the trigger overwrites it.
- `touch_updated_at()` trigger function: bumps `updated_at` on every UPDATE.
- `audit_member_change()` trigger function: AFTER INSERT/UPDATE on members, writes a
   snapshot of the old and new row state to `audit_logs`.

## Security (RLS)
- `members`: public SELECT (only verification-safe columns exist on the table; sensitive
  details like document scans are gated behind status checks in app logic), authenticated
  full CRUD for the admin. Update/delete restricted to authenticated admin.
- `duplicate_flags`: authenticated full CRUD (admin-only).
- `audit_logs`: authenticated read + insert; inserts are also allowed via the trigger
  running as the authenticated session.
- `system_settings`: public read (template metadata needed to render public certs),
  authenticated write (admin configures the template).

## Important Notes
1. The members table intentionally omits email/phone fields — the public verification
   page must never expose contact details. document_url is stored but only surfaced
   to the admin, never to the public search.
2. The UID sequence is derived from a per-year counter table (`member_uid_seq`) so
   numbers are dense and human-readable rather than random.
3. Status is constrained via CHECK to the four allowed values:
   'Pending Verification', 'New', 'Renewed', 'Inactive'.
*/

-- =========================================================
-- 1. MEMBERS
-- =========================================================
CREATE TABLE IF NOT EXISTS members (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    uid varchar(50) UNIQUE NOT NULL,
    first_name varchar(100) NOT NULL,
    last_name varchar(100) NOT NULL,
    parish varchar(255) NOT NULL,
    ministries text[] NOT NULL DEFAULT '{}',
    status varchar(30) NOT NULL DEFAULT 'Pending Verification'
        CHECK (status IN ('Pending Verification','New','Renewed','Inactive')),
    document_url text,
    notes text,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_members_status ON members(status);
CREATE INDEX IF NOT EXISTS idx_members_name ON members(lower(first_name), lower(last_name));
CREATE INDEX IF NOT EXISTS idx_members_parish ON members(lower(parish));
CREATE INDEX IF NOT EXISTS idx_members_uid ON members(uid);

ALTER TABLE members ENABLE ROW LEVEL SECURITY;

-- Public can read member records (verification search). Sensitive columns
-- (document_url, notes) are not surfaced by the public query layer in app code.
DROP POLICY IF EXISTS "public_select_members" ON members;
CREATE POLICY "public_select_members"
ON members FOR SELECT
TO anon, authenticated USING (true);

-- Only authenticated admin can write.
DROP POLICY IF EXISTS "admin_insert_members" ON members;
CREATE POLICY "admin_insert_members"
ON members FOR INSERT
TO authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "admin_update_members" ON members;
CREATE POLICY "admin_update_members"
ON members FOR UPDATE
TO authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "admin_delete_members" ON members;
CREATE POLICY "admin_delete_members"
ON members FOR DELETE
TO authenticated USING (true);

-- =========================================================
-- 2. DUPLICATE FLAGS (Pending Merges queue)
-- =========================================================
CREATE TABLE IF NOT EXISTS duplicate_flags (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    existing_member_id uuid REFERENCES members(id) ON DELETE CASCADE,
    incoming_first_name varchar(100),
    incoming_last_name varchar(100),
    incoming_parish varchar(255),
    incoming_ministries text[] DEFAULT '{}',
    incoming_data jsonb NOT NULL,
    resolved boolean NOT NULL DEFAULT false,
    resolution varchar(30),  -- 'merged' | 'separate'
    resolved_at timestamptz,
    created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_dupflags_resolved ON duplicate_flags(resolved);

ALTER TABLE duplicate_flags ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "admin_select_dupflags" ON duplicate_flags;
CREATE POLICY "admin_select_dupflags"
ON duplicate_flags FOR SELECT
TO authenticated USING (true);

DROP POLICY IF EXISTS "admin_insert_dupflags" ON duplicate_flags;
CREATE POLICY "admin_insert_dupflags"
ON duplicate_flags FOR INSERT
TO authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "admin_update_dupflags" ON duplicate_flags;
CREATE POLICY "admin_update_dupflags"
ON duplicate_flags FOR UPDATE
TO authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "admin_delete_dupflags" ON duplicate_flags;
CREATE POLICY "admin_delete_dupflags"
ON duplicate_flags FOR DELETE
TO authenticated USING (true);

-- =========================================================
-- 3. AUDIT LOGS (append-only paper trail)
-- =========================================================
CREATE TABLE IF NOT EXISTS audit_logs (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    member_id uuid,
    admin_action varchar(100) NOT NULL,
    previous_state jsonb,
    new_state jsonb,
    timestamp timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_audit_member ON audit_logs(member_id);
CREATE INDEX IF NOT EXISTS idx_audit_timestamp ON audit_logs(timestamp DESC);

ALTER TABLE audit_logs ENABLE ROW LEVEL SECURITY;

-- Read-only for admin; inserts come from the trigger (runs as the caller).
DROP POLICY IF EXISTS "admin_select_auditlogs" ON audit_logs;
CREATE POLICY "admin_select_auditlogs"
ON audit_logs FOR SELECT
TO authenticated USING (true);

DROP POLICY IF EXISTS "admin_insert_auditlogs" ON audit_logs;
CREATE POLICY "admin_insert_auditlogs"
ON audit_logs FOR INSERT
TO authenticated WITH CHECK (true);

-- =========================================================
-- 4. SYSTEM SETTINGS (key/value JSONB)
-- =========================================================
CREATE TABLE IF NOT EXISTS system_settings (
    key varchar(50) PRIMARY KEY,
    value jsonb NOT NULL,
    updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE system_settings ENABLE ROW LEVEL SECURITY;

-- Public can read settings (needed to find the certificate template path for public cert rendering).
DROP POLICY IF EXISTS "public_select_settings" ON system_settings;
CREATE POLICY "public_select_settings"
ON system_settings FOR SELECT
TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "admin_update_settings" ON system_settings;
CREATE POLICY "admin_update_settings"
ON system_settings FOR UPDATE
TO authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "admin_insert_settings" ON system_settings;
CREATE POLICY "admin_insert_settings"
ON system_settings FOR INSERT
TO authenticated WITH CHECK (true);

-- Seed default certificate template settings.
INSERT INTO system_settings (key, value)
VALUES (
    'certificate_template',
    '{"template_url": null, "name_x": 300, "name_y": 320, "parish_x": 300, "parish_y": 400, "ministry_x": 300, "ministry_y": 460, "year_x": 300, "year_y": 540, "qr_x": 560, "qr_y": 720, "qr_size": 120, "liturgical_year": "2026"}'
) ON CONFLICT (key) DO NOTHING;

-- =========================================================
-- 5. UID SEQUENCE TABLE (per-year human-readable counter)
-- =========================================================
CREATE TABLE IF NOT EXISTS member_uid_seq (
    year int PRIMARY KEY,
    next_seq int NOT NULL DEFAULT 1
);

ALTER TABLE member_uid_seq ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "admin_all_uidseq" ON member_uid_seq;
CREATE POLICY "admin_all_uidseq"
ON member_uid_seq FOR ALL
TO authenticated USING (true) WITH CHECK (true);

-- =========================================================
-- 6. TRIGGERS & FUNCTIONS
-- =========================================================

-- Generate LMD-<year>-#### UID on insert.
CREATE OR REPLACE FUNCTION generate_member_uid()
RETURNS trigger AS $$
DECLARE
    v_year int;
    v_seq int;
BEGIN
    v_year := EXTRACT(YEAR FROM now())::int;
    INSERT INTO member_uid_seq (year, next_seq)
    VALUES (v_year, 2)
    ON CONFLICT (year) DO UPDATE SET next_seq = member_uid_seq.next_seq + 1
    RETURNING next_seq INTO v_seq;
    -- v_seq is the NEXT value after insert; the one we assign is v_seq-1.
    v_seq := v_seq - 1;
    NEW.uid := 'LMD-' || v_year || '-' || lpad(v_seq::text, 4, '0');
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_generate_member_uid ON members;
CREATE TRIGGER trg_generate_member_uid
BEFORE INSERT ON members
FOR EACH ROW EXECUTE FUNCTION generate_member_uid();

-- Touch updated_at on update.
CREATE OR REPLACE FUNCTION touch_updated_at()
RETURNS trigger AS $$
BEGIN
    NEW.updated_at := now();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_touch_updated_at ON members;
CREATE TRIGGER trg_touch_updated_at
BEFORE UPDATE ON members
FOR EACH ROW EXECUTE FUNCTION touch_updated_at();

-- Audit log on member insert/update.
CREATE OR REPLACE FUNCTION audit_member_change()
RETURNS trigger AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        INSERT INTO audit_logs (member_id, admin_action, previous_state, new_state)
        VALUES (NEW.id, 'Manual Creation', NULL, to_jsonb(NEW));
        RETURN NEW;
    ELSIF TG_OP = 'UPDATE' THEN
        INSERT INTO audit_logs (member_id, admin_action, previous_state, new_state)
        VALUES (NEW.id,
                CASE WHEN OLD.status IS DISTINCT FROM NEW.status THEN 'Status Update' ELSE 'Profile Update' END,
                to_jsonb(OLD), to_jsonb(NEW));
        RETURN NEW;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_audit_member ON members;
CREATE TRIGGER trg_audit_member
AFTER INSERT OR UPDATE ON members
FOR EACH ROW EXECUTE FUNCTION audit_member_change();
