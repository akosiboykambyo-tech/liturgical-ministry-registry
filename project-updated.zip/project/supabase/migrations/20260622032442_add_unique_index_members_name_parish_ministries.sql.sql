-- Unique constraint: (first_name, last_name, parish, ministries)
-- Prevents importing the same person (same name + parish + ministries set) twice.
-- Using an indexable expression on the ministries array so that array equality
-- (same elements, same order) is treated as a duplicate. If your imports may list
-- ministries in different order, consider a normalized GIN index instead; this
-- index treats arrays as duplicates only when element order matches.
CREATE UNIQUE INDEX IF NOT EXISTS uq_members_name_parish_ministries
ON members (lower(first_name), lower(last_name), lower(parish), ministries);
