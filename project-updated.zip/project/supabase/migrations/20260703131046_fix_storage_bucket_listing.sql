-- Fix: Remove overly permissive storage policy that allows listing
-- Public buckets don't need SELECT policies for direct object access
-- This policy allowed listing all files which exposes more data than intended

DROP POLICY IF EXISTS "Allow public read access to templates" ON storage.objects;