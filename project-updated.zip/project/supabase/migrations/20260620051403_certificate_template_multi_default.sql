-- =========================================================
-- Multi-template support for system_settings
--
-- Adds an admin DELETE policy for templates, guarantees exactly
-- one default certificate_template row via a unique partial index,
-- and back-fills the legacy seeded 'certificate_template' row
-- (if present) so it becomes the default. New rows created by the
-- Admin Console are keyed certificate_template_<slug>; the public
-- verify page now selects WHERE is_default = true instead of a
-- hardcoded key.
-- =========================================================

-- 1. Admin DELETE policy for system_settings (templates can be removed).
DROP POLICY IF EXISTS "admin_delete_settings" ON system_settings;
CREATE POLICY "admin_delete_settings"
ON system_settings FOR DELETE
TO authenticated
USING ((auth.jwt() ->> 'email') = 'cowlkalookan2025@gmail.com');

-- 2. Unique partial index: at most ONE row may have is_default = true.
--    Partial index (WHERE is_default) keeps it small and lets non-default
--    rows coexist without constraint violations.
CREATE UNIQUE INDEX IF NOT EXISTS system_settings_single_default
ON system_settings (is_default)
WHERE is_default = true;

-- 3. Back-fill the legacy seeded row (if it exists) to be the default so
--    existing public certificate rendering keeps working without a manual
--    admin action. Only the 'certificate_template' legacy key, not the new
--    certificate_template_<slug> keys, is touched here.
UPDATE system_settings
SET is_default = true
WHERE key = 'certificate_template';
