-- Security hardening migration - Part 2: Create secure functions

-- ============================================================================
-- 1. Create functions with explicit search_path
-- ============================================================================

-- generate_member_uid
CREATE OR REPLACE FUNCTION generate_member_uid()
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_year int := EXTRACT(YEAR FROM now());
  v_count int;
  v_uid text;
BEGIN
  SELECT COUNT(*) + 1 INTO v_count
  FROM members
  WHERE uid LIKE 'LMD-' || v_year || '-%';
  
  v_uid := 'LMD-' || v_year || '-' || LPAD(v_count::text, 4, '0');
  RETURN v_uid;
END;
$$;

-- assign_member_uid (trigger function)
CREATE OR REPLACE FUNCTION assign_member_uid()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.uid IS NULL OR NEW.uid = 'PENDING' THEN
    NEW.uid := generate_member_uid();
  END IF;
  RETURN NEW;
END;
$$;

-- log_member_changes (trigger function)
CREATE OR REPLACE FUNCTION log_member_changes()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    INSERT INTO audit_logs (member_id, admin_action, previous_state, new_state)
    VALUES (NEW.id, 'INSERT', null, to_jsonb(NEW));
  ELSIF TG_OP = 'UPDATE' THEN
    INSERT INTO audit_logs (member_id, admin_action, previous_state, new_state)
    VALUES (NEW.id, 'UPDATE', to_jsonb(OLD), to_jsonb(NEW));
  ELSIF TG_OP = 'DELETE' THEN
    INSERT INTO audit_logs (member_id, admin_action, previous_state, new_state)
    VALUES (OLD.id, 'DELETE', to_jsonb(OLD), null);
  END IF;
  RETURN COALESCE(NEW, OLD);
END;
$$;

-- merge_duplicate_members
CREATE OR REPLACE FUNCTION merge_duplicate_members(
  p_primary_id uuid,
  p_duplicate_ids uuid[],
  p_merged_ministries text[]
)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_primary_uid text;
  v_deleted_count int;
BEGIN
  SELECT uid INTO v_primary_uid FROM members WHERE id = p_primary_id;
  IF v_primary_uid IS NULL THEN
    RETURN json_build_object(
      'success', false,
      'error', 'Primary member not found'
    );
  END IF;

  UPDATE members
  SET 
    ministries = p_merged_ministries,
    updated_at = now()
  WHERE id = p_primary_id;

  DELETE FROM members
  WHERE id = ANY(p_duplicate_ids);

  GET DIAGNOSTICS v_deleted_count = ROW_COUNT;

  DELETE FROM duplicate_flags
  WHERE existing_member_id = ANY(p_duplicate_ids);

  RETURN json_build_object(
    'success', true,
    'primary_id', p_primary_id,
    'deleted_count', v_deleted_count
  );
END;
$$;

-- resolve_scanned_duplicate_merge
CREATE OR REPLACE FUNCTION resolve_scanned_duplicate_merge(
  p_scanned_id uuid
)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_member_ids uuid[];
  v_primary_id uuid;
  v_sorted_ids uuid[];
  v_merged_ministries text[];
BEGIN
  SELECT member_ids INTO v_member_ids
  FROM scanned_duplicates
  WHERE id = p_scanned_id AND resolved = false;

  IF v_member_ids IS NULL OR array_length(v_member_ids, 1) IS NULL THEN
    RETURN json_build_object(
      'success', false,
      'error', 'Scanned duplicate group not found or already resolved'
    );
  END IF;

  SELECT id INTO v_primary_id
  FROM members
  WHERE id = ANY(v_member_ids)
  ORDER BY created_at ASC
  LIMIT 1;

  IF v_primary_id IS NULL THEN
    RETURN json_build_object(
      'success', false,
      'error', 'No members found for the scanned group'
    );
  END IF;

  SELECT array_agg(DISTINCT ministry) INTO v_merged_ministries
  FROM (
    SELECT unnest(ministries) AS ministry
    FROM members
    WHERE id = ANY(v_member_ids)
  ) AS m;

  SELECT array_agg(id) INTO v_sorted_ids
  FROM members
  WHERE id = ANY(v_member_ids) AND id != v_primary_id;

  PERFORM merge_duplicate_members(v_primary_id, v_sorted_ids, v_merged_ministries);

  UPDATE scanned_duplicates
  SET 
    resolved = true,
    resolution = 'merged',
    resolved_at = now()
  WHERE id = p_scanned_id;

  UPDATE scanned_duplicates
  SET 
    resolved = true,
    resolution = 'members_deleted',
    resolved_at = now()
  WHERE resolved = false
    AND id != p_scanned_id
    AND member_ids && v_sorted_ids;

  RETURN json_build_object(
    'success', true,
    'primary_id', v_primary_id,
    'deleted_ids', v_sorted_ids,
    'merged_ministries', v_merged_ministries
  );
END;
$$;

-- resolve_scanned_duplicate_separate
CREATE OR REPLACE FUNCTION resolve_scanned_duplicate_separate(
  p_scanned_id uuid
)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  UPDATE scanned_duplicates
  SET 
    resolved = true,
    resolution = 'separate',
    resolved_at = now()
  WHERE id = p_scanned_id AND resolved = false;

  IF NOT FOUND THEN
    RETURN json_build_object(
      'success', false,
      'error', 'Scanned duplicate group not found or already resolved'
    );
  END IF;

  RETURN json_build_object('success', true);
END;
$$;

-- merge_incoming_duplicate
CREATE OR REPLACE FUNCTION merge_incoming_duplicate(
  p_flag_id uuid,
  p_existing_member_id uuid
)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_existing_ministries text[];
  v_incoming_ministries text[];
  v_merged_ministries text[];
  v_flag record;
BEGIN
  SELECT * INTO v_flag
  FROM duplicate_flags
  WHERE id = p_flag_id AND resolved = false;

  IF v_flag.id IS NULL THEN
    RETURN json_build_object(
      'success', false,
      'error', 'Duplicate flag not found or already resolved'
    );
  END IF;

  SELECT ministries INTO v_existing_ministries
  FROM members
  WHERE id = p_existing_member_id;

  IF v_existing_ministries IS NULL THEN
    RETURN json_build_object(
      'success', false,
      'error', 'Existing member not found'
    );
  END IF;

  v_incoming_ministries := v_flag.incoming_ministries;

  SELECT array_agg(DISTINCT ministry) INTO v_merged_ministries
  FROM (
    SELECT unnest(v_existing_ministries) AS ministry
    UNION
    SELECT unnest(v_incoming_ministries) AS ministry
  ) AS m;

  UPDATE members
  SET 
    ministries = v_merged_ministries,
    updated_at = now()
  WHERE id = p_existing_member_id;

  UPDATE duplicate_flags
  SET 
    resolved = true,
    resolution = 'merged',
    resolved_at = now()
  WHERE id = p_flag_id;

  RETURN json_build_object(
    'success', true,
    'member_id', p_existing_member_id,
    'merged_ministries', v_merged_ministries
  );
END;
$$;

-- create_separate_member_from_flag
CREATE OR REPLACE FUNCTION create_separate_member_from_flag(
  p_flag_id uuid
)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_flag record;
  v_new_member_id uuid;
BEGIN
  SELECT * INTO v_flag
  FROM duplicate_flags
  WHERE id = p_flag_id AND resolved = false;

  IF v_flag.id IS NULL THEN
    RETURN json_build_object(
      'success', false,
      'error', 'Duplicate flag not found or already resolved'
    );
  END IF;

  INSERT INTO members (
    first_name,
    last_name,
    parish,
    ministries,
    status,
    uid
  )
  VALUES (
    v_flag.incoming_first_name,
    v_flag.incoming_last_name,
    v_flag.incoming_parish,
    v_flag.incoming_ministries,
    'Pending Verification',
    'PENDING'
  )
  RETURNING id INTO v_new_member_id;

  UPDATE duplicate_flags
  SET 
    resolved = true,
    resolution = 'separate',
    resolved_at = now()
  WHERE id = p_flag_id;

  RETURN json_build_object(
    'success', true,
    'new_member_id', v_new_member_id
  );
END;
$$;

-- set_default_certificate_template
CREATE OR REPLACE FUNCTION set_default_certificate_template(p_key text)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  UPDATE system_settings
  SET is_default = (key = p_key);
END;
$$;

-- ============================================================================
-- 2. Recreate triggers
-- ============================================================================

-- Recreate the member UID trigger
DROP TRIGGER IF EXISTS trg_assign_member_uid ON members;
CREATE TRIGGER trg_assign_member_uid
  BEFORE INSERT ON members
  FOR EACH ROW
  EXECUTE FUNCTION assign_member_uid();

-- Recreate the audit log trigger
DROP TRIGGER IF EXISTS trg_log_member_changes ON members;
CREATE TRIGGER trg_log_member_changes
  AFTER INSERT OR UPDATE OR DELETE ON members
  FOR EACH ROW
  EXECUTE FUNCTION log_member_changes();

-- ============================================================================
-- 3. Fix RLS Policy Always True issues on scanned_duplicates
-- ============================================================================

-- Drop the old overly permissive policies
DROP POLICY IF EXISTS delete_scanned_duplicates ON scanned_duplicates;
DROP POLICY IF EXISTS insert_scanned_duplicates ON scanned_duplicates;
DROP POLICY IF EXISTS update_scanned_duplicates ON scanned_duplicates;
DROP POLICY IF EXISTS select_scanned_duplicates ON scanned_duplicates;

-- Create new restrictive policies (authenticated users only, no anon access)
CREATE POLICY select_scanned_duplicates ON scanned_duplicates FOR SELECT
  TO authenticated USING (true);

CREATE POLICY insert_scanned_duplicates ON scanned_duplicates FOR INSERT
  TO authenticated WITH CHECK (true);

CREATE POLICY update_scanned_duplicates ON scanned_duplicates FOR UPDATE
  TO authenticated USING (true) WITH CHECK (true);

CREATE POLICY delete_scanned_duplicates ON scanned_duplicates FOR DELETE
  TO authenticated USING (true);

-- ============================================================================
-- 4. Grant EXECUTE to authenticated only (not anon)
-- ============================================================================

GRANT EXECUTE ON FUNCTION merge_duplicate_members(uuid, uuid[], text[]) TO authenticated;
GRANT EXECUTE ON FUNCTION resolve_scanned_duplicate_merge(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION resolve_scanned_duplicate_separate(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION merge_incoming_duplicate(uuid, uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION create_separate_member_from_flag(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION set_default_certificate_template(text) TO authenticated;
GRANT EXECUTE ON FUNCTION generate_member_uid() TO authenticated;