-- Security hardening migration - Part 1: Drop existing functions

-- Drop functions that need to be recreated with SET search_path
DROP FUNCTION IF EXISTS generate_member_uid() CASCADE;
DROP FUNCTION IF EXISTS assign_member_uid() CASCADE;
DROP FUNCTION IF EXISTS log_member_changes() CASCADE;
DROP FUNCTION IF EXISTS merge_duplicate_members(uuid, uuid[], text[]);
DROP FUNCTION IF EXISTS resolve_scanned_duplicate_merge(uuid);
DROP FUNCTION IF EXISTS resolve_scanned_duplicate_separate(uuid);
DROP FUNCTION IF EXISTS merge_incoming_duplicate(uuid, uuid);
DROP FUNCTION IF EXISTS create_separate_member_from_flag(uuid);
DROP FUNCTION IF EXISTS set_default_certificate_template(text);