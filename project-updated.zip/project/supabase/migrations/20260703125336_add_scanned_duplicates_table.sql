-- Scanned duplicates table: stores groups of existing members detected as duplicates
-- during a system-wide scan. These are records that slipped through before
-- duplicate detection was properly configured.
CREATE TABLE IF NOT EXISTS scanned_duplicates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  group_key text NOT NULL, -- composite key: "normalized_name|normalized_parish"
  member_ids text[] NOT NULL, -- array of member IDs in this duplicate group
  member_count int NOT NULL DEFAULT 1,
  resolved boolean NOT NULL DEFAULT false,
  resolution text, -- 'merged' | 'separate' | null
  resolved_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(group_key)
);

-- Index for faster lookups
CREATE INDEX IF NOT EXISTS idx_scanned_duplicates_resolved ON scanned_duplicates(resolved);
CREATE INDEX IF NOT EXISTS idx_scanned_duplicates_group_key ON scanned_duplicates(group_key);

-- Enable RLS
ALTER TABLE scanned_duplicates ENABLE ROW LEVEL SECURITY;

-- RLS policies
CREATE POLICY "select_scanned_duplicates" ON scanned_duplicates FOR SELECT
  TO authenticated USING (true);
CREATE POLICY "insert_scanned_duplicates" ON scanned_duplicates FOR INSERT
  TO authenticated WITH CHECK (true);
CREATE POLICY "update_scanned_duplicates" ON scanned_duplicates FOR UPDATE
  TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "delete_scanned_duplicates" ON scanned_duplicates FOR DELETE
  TO authenticated USING (true);