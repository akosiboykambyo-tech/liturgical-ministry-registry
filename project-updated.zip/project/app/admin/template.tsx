"use client";

// Sits alongside app/admin/layout.tsx (same segment). Next.js remounts a
// template on every navigation within its segment, while the layout above
// it (and therefore the sidebar) stays mounted — so switching between
// Dashboard / Members / Certificates etc. gets a smooth transition without
// the sidebar flashing or losing state.
export default function AdminTemplate({ children }: { children: React.ReactNode }) {
  return <div className="animate-page-in">{children}</div>;
}
